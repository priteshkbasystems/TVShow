﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace TVShows.Templates
{
	public partial class ArticleFeedItemTemplate : ContentView
	{
		public ArticleFeedItemTemplate ()
		{
			InitializeComponent ();
		}
	}
}

