﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
namespace TVShows.Templates
{
	public partial class TVShowItemTemplate : ContentView
	{
		public TVShowItemTemplate()
		{
			InitializeComponent ();
		}
	}
}
