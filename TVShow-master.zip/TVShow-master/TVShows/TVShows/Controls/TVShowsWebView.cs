﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace TVShows.Controls
{
    public class TVShowsWebView : WebView
    {
        public TVShowsWebView(): base() { }
    }
}
